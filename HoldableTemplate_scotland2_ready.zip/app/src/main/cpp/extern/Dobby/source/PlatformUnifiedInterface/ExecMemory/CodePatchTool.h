#pragma once

MemoryOperationError DobbyCodePatch(void *address, uint8_t *buffer, uint32_t buffer_size);